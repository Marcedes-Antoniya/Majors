# Major Calculator

Calculates how close a Dartmouth Student is to each major within a certain range of classes. 

## TESTING

To sample run on my small data set, see example by running `check_major.py`. 